package exercises;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex06_MagicTriangleTest
{
    @ParameterizedTest(name = "isMagic({0})? {1}")
    @MethodSource("listInputsAndExpected")
    public void isMagic(final List<Integer> inputs, final boolean expected)
    {
        // TODO
    }

    static Stream<Arguments> listInputsAndExpected()
    {
        return Stream.of(Arguments.of(List.of(1, 2, 3, 4, 5, 6), false),
        				 Arguments.of(List.of(2, 6, 1, 5, 3, 4), true),
                         Arguments.of(List.of(1, 5, 3, 4, 2, 6), true),
                         Arguments.of(List.of(2, 5, 9, 1, 6, 7, 3, 4, 8), true),
                         Arguments.of(List.of(1, 2, 3, 4, 5, 6, 7, 8, 9), false));
    }
}
