package exercises;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex02_AnagramTest {

	public void isAnagram(String word1, String word2, boolean expected) {
		
	}
	
	@ParameterizedTest(name = "allAnagrams({0}) = {1}")
	@MethodSource("argumentProvider")
	public void allAnagrams(List<String> words, boolean expected) {
		
	}
	
	static Stream<Arguments> argumentProvider() {
		return Stream.of(Arguments.of(List.of("pairs", "paris"), true), 
				Arguments.of(List.of("Tim", "Jim"), false),
				Arguments.of(List.of("Ampel", "Lampe", "Palme"), true));
	}
}