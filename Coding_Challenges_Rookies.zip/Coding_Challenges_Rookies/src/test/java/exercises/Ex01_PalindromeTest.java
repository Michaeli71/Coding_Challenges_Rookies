package exercises;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex01_PalindromeTest {

	//@ParameterizedTest(name = "calcPrimes({0}) = {1}")
	//@CsvSource( // TODO
	public void isPalindrome(String input, boolean expected) {
	}
	
	public void isPalindromeWithRange(String input, int left, int right, boolean expected) {
		
	}
}
