package exercises;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex03_DivisorsTest {

	@ParameterizedTest(name = "calcProperDivisors({0}) = {1}")
	@MethodSource("argumentProvider")
	public void calcProperDivisors(int number, List<Integer> expected) {

	}
	
	static Stream<Arguments> argumentProvider() {
		return Stream.of(Arguments.of(1, List.of(1)), // to be defined / discussed
				Arguments.of(2, List.of(1)),
				Arguments.of(4, List.of(1, 2)),
				Arguments.of(6, List.of(1, 2, 3)),
				Arguments.of(20, List.of(1, 2, 4, 5, 10)),
				Arguments.of(70, List.of(1, 2, 5, 7, 10, 14, 35)));
	}
}
