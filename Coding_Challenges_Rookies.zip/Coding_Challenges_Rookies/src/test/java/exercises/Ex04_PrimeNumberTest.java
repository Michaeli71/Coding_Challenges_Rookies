package exercises;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex04_PrimeNumberTest
{
    public void calcPrimes()
    {
    }
    
	// TODO
}
