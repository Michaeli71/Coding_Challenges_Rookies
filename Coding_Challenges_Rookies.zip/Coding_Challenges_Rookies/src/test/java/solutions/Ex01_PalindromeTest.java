package solutions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex01_PalindromeTest {

	@ParameterizedTest(name = "calcPrimes({0}) = {1}")
	@CsvSource({"Otto, true", "Jim, false", "Was It A Car Or A Cat I Saw, true"})
	public void isPalindrome(String input, boolean expected) {
		
		boolean isPalindrome = Ex01_Palindrome.isPalindrome(input);
		
		assertEquals(expected, isPalindrome);
	}
	
	@ParameterizedTest(name = "calcPrimes({0}, {1}, {2}) = {3}")
	@CsvSource({"AB_GHIHG_XYZ, 3, 7, true", "AB_GHIHG_XYZ, 3, 5, false"})
	public void isPalindromeWithRange(String input, int left, int right, boolean expected) {
		
		boolean isPalindrome = Ex01_Palindrome.isPalindrome("AB_GHIHG_XYZ", left, right);

		assertEquals(expected, isPalindrome);
	}
}
