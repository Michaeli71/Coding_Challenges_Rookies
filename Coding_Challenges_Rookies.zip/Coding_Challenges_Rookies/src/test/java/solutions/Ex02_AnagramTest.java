package solutions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex02_AnagramTest {

	@ParameterizedTest(name = "isAnagram({0}, {1}) = {2}")
	@CsvSource({"Otto, Toto, true", "Sun, Moon, false", "Reactive, creative, true"})
	public void isAnagram(String word1, String word2, boolean expected) {
		
		boolean isPalindrome = Ex02_Anagram.isAnagram(word1, word2);
		
		assertEquals(expected, isPalindrome);
	}
	
	@ParameterizedTest(name = "allAnagrams({0}) = {1}")
	@MethodSource("argumentProvider")
	public void allAnagrams(List<String> words, boolean expected) {
		
		boolean allAnagrams = Ex02_Anagram.allAnagrams(words);
		
		assertEquals(expected, allAnagrams);
	}
	
	static Stream<Arguments> argumentProvider() {
		return Stream.of(Arguments.of(List.of("pairs", "paris", "spira"), true), 
				Arguments.of(List.of("Tim", "Jim"), false),
				Arguments.of(List.of("Ampel", "Lampe", "Palme"), true));
	}
}