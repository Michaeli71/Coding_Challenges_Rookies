package exercises;

import java.util.List;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex03_Divisors {

	public static void main(String[] args) {
		System.out.println("calcProperDivisors(6): " + calcProperDivisors(6));
		System.out.println("calcProperDivisors(70): " + calcProperDivisors(70));
	}

	private static List<Integer> calcProperDivisors(int i) {
		return List.of();
	}

}
