package exercises;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex06_MagicTriangle
{
    public static void main(String[] args)
    {
        /*
         *      2
               8  5
              4     9
             3 7  6 1
         */
    }
}