package exercises;

import java.util.List;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex04_PrimeNumber
{
	private Ex04_PrimeNumber()
	{
	}

	public static List<Integer> calcPrimesUpTo(final int maxValue) {
		return null;
	}

	// TODO
}
