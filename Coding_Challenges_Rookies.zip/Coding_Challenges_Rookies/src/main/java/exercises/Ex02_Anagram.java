package exercises;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex02_Anagram {

	public static void main(String[] args) {
		System.out.println("isAnagram('lamp', 'palm'): " + isAnagram("lamp", "palm"));
		System.out.println("isAnagram('Otto', 'Toto'): " + isAnagram("Otto", "Toto"));
		System.out.println("isAnagram('Paris', 'pairs'): " + isAnagram("Paris", "pairs"));

		System.out.println("isAnagram('Sun', 'Moon'): " + isAnagram("Sun", "Moon"));
	}

	static boolean isAnagram(String word1, String word2) {
		return false;
	}

}
