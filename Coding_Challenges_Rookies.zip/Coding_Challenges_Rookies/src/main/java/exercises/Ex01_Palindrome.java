package exercises;


/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex01_Palindrome {

	public static void main(String[] args) {

		System.out.println("isPalindrome('Otto'): " + isPalindrome("Otto"));
		System.out.println("isPalindrome('Jim'): " + isPalindrome("Jim"));
		System.out.println("isPalindrome('Was It A Car Or A Cat I Saw'): " + isPalindrome("Was It A Car Or A Cat I Saw"));
	}

	static boolean isPalindrome(String text) {
		return false;
	}

}
