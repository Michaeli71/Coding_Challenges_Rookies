package exercises;

import java.util.List;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex05_ZickZackExample {

	public static void main(String[] args) {
	
		List<String> zickZack1 = generateZickZack("a very warm welcome in the automated system testing team", 9);
		zickZack1.forEach(System.out::println);
		
		List<String> sinus = generateSinus("a very warm welcome in the automated system testing team", 10);
		sinus.forEach(System.out::println);	
	}

	// idee: Erzeuge eine Ziel-Datenstruktur und laufe dann Zeichen f�r Zeichen
	// platziere dieses an gew�nschten Position
	static List<String> generateZickZack(final String input, final int height)
	{
		return List.of();
	}

	
	
	// idee: Erzeuge eine Ziel-Datenstruktur und laufe dann Zeichen f�r Zeichen
	// platziere dieses an gew�nschten Position
	static List<String> generateSinus(final String input, final int height)
	{
		return List.of();
	}
	
    public static void printArray(final char[][] values)
    {
        for (int y = 0; y < values.length; y++)
        {
            for (int x = 0; x < values[y].length; x++)
            {
            	char value = values[y][x];
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}
