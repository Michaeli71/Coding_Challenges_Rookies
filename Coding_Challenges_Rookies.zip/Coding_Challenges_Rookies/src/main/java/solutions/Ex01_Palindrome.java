package solutions;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex01_Palindrome {

	public static void main(String[] args) {
		System.out.println("isPalindrome('Otto'): " + isPalindrome("Otto"));
		System.out.println("isPalindrome('Jim'): " + isPalindrome("Jim"));
		System.out.println("isPalindrome('Was It A Car Or A Cat I Saw'): " + isPalindrome("Was It A Car Or A Cat I Saw"));
		
		// Bonus
		System.out.println("isPalindrome('AB_GHIHG_XYZ', 3, 7): " + isPalindrome("AB_GHIHG_XYZ", 3, 7));
		System.out.println("isPalindrome('AB_GHIHG_XYZ', 3, 5): " + isPalindrome("AB_GHIHG_XYZ", 3, 5));
	}

	static boolean isPalindrome(String text)
	{
		if (text.isEmpty())
			return true;
		if (text.length() == 1)
			return true;
		
		// check left and right character, if same move to the middle until
		// left and right pointer cross
		boolean isPalindrome = true;
		String adjustedInput = text.toUpperCase().replace(" ", "");
		int leftIdx = 0;
		int rightIdx = adjustedInput.length() - 1;
		while (leftIdx < rightIdx && isPalindrome)
		{
			isPalindrome = adjustedInput.charAt(leftIdx) == adjustedInput.charAt(rightIdx);
			leftIdx++;
			rightIdx--;
		}
		
		return isPalindrome;
	}
	
	static boolean isPalindrome(String text, int leftIdx, int rightIdx)
	{
		if (leftIdx > rightIdx)
			throw new IllegalArgumentException("invalid range");
		
		// check left and right character, if same move to the middle until
		// left and right pointer cross
		boolean isPalindrome = true;
		String adjustedInput = text.toUpperCase();
		while (leftIdx < rightIdx && isPalindrome)
		{
			isPalindrome = adjustedInput.charAt(leftIdx) == adjustedInput.charAt(rightIdx);
			leftIdx++;
			rightIdx--;
		}
		
		return isPalindrome;
	}
}
