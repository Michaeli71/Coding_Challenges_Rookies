package solutions;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex03_Divisors {

	public static void main(String[] args) {
		System.out.println("calcProperDivisors(6): " + calcProperDivisors(6));
		System.out.println("calcProperDivisors(70): " + calcProperDivisors(70));
	}

	static List<Integer> calcProperDivisors(int number)
	{
		List<Integer> divisors = new ArrayList<>(List.of(1));
		
		for (int i = 2; i <= (number + 1) / 2; i++)			
		{
			if (number % i == 0)
				divisors.add(i);
		}
		
		return divisors;
	}
}
