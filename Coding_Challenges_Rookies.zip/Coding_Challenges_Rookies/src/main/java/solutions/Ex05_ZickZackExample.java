package solutions;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm f�r das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex05_ZickZackExample {

	public static void main(String[] args) {
	
		List<String> zickZack1 = generateZickZack("a very warm welcome in the automated system testing team", 9);
		zickZack1.forEach(System.out::println);
		
		List<String> sinus = generateSinus("a very warm welcome in the automated system testing team", 10);
		sinus.forEach(System.out::println);	
	}

	// idee: Erzeuge eine Ziel-Datenstruktur und laufe dann Zeichen f�r Zeichen
	// platziere dieses an gew�nschten Position
	static List<String> generateZickZack(final String input, final int height)
	{
		final char[][] tmp = createTempCharArray(input, height);
		
		int x = 0;
		int y = 0;
		boolean down = true;  
		while (x < input.length())
		{
			tmp[y][x] = input.charAt(x);
			
			x++;
			if (down)
			{
				y++;
				if (y == height - 1)
					down = false;
			}				
			else
			{
				y--;
				if (y == 0)
					down = true;
			}
		}
		
		return convertToLines(tmp);
	}

	private static char[][] createTempCharArray(final String input, final int height) {
		final char[][] tmp = new char[height][input.length()];
		
		for (int y = 0; y < height; y++)
			for (int x = 0; x < input.length(); x++)
				tmp[y][x] = ' ';
		
		return tmp;
	}

	private static List<String> convertToLines(char[][] lines) {
		final List<String> result = new ArrayList<>();
		
		for (char[] lineChars : lines)
		{
			result.add(new String(lineChars));
		}
		return result;
	}
	
	
	// idee: Erzeuge eine Ziel-Datenstruktur und laufe dann Zeichen f�r Zeichen
	// platziere dieses an gew�nschten Position
	static List<String> generateSinus(final String input, final int height)
	{
		char[][] tmp = createTempCharArray(input, height);
		
		int x = 0;
		int y = 0;
		while (x < input.length())
		{
			y = (int) (height/2 + (Math.sin(Math.toRadians(x * 6)) * (height/2-1)));

			tmp[y][x] = input.charAt(x);
			
			x++;		
		}
		
		return convertToLines(tmp);
	}
	
    public static void printArray(final char[][] values)
    {
        for (int y = 0; y < values.length; y++)
        {
            for (int x = 0; x < values[y].length; x++)
            {
            	char value = values[y][x];
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}
