package solutions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Beispielprogramm für das Buch "Java Challenge"
 *
 * @author Michael Inden
 *
 * Copyright 2020 by Michael Inden
 */
public class Ex02_Anagram {

	public static void main(String[] args) {
		System.out.println("isAnagram('lamp', 'palm'): " + isAnagram("lamp", "palm"));
		System.out.println("isAnagram('Otto', 'Toto'): " + isAnagram("Otto", "Toto"));
		System.out.println("isAnagram('Paris', 'pairs'): " + isAnagram("Paris", "pairs"));

		System.out.println("isAnagram('Sun', 'Moon'): " + isAnagram("Sun", "Moon"));
	}

	static boolean isAnagram(String word1, String word2) {
		// idea: build up a dictionary (could be even an array with count of chars)
		Map<Character, Integer> charCount1 = buildCharHistogram(word1.toUpperCase());
		Map<Character, Integer> charCount2 = buildCharHistogram(word2.toUpperCase());

		return charCount1.equals(charCount2);
	}

	private static Map<Character, Integer> buildCharHistogram(String input) {

		Map<Character, Integer> charFrequencies = new HashMap<>();
		for (char ch : input.toCharArray()) {
			/*
			if (charFrequencies.containsKey(ch))
			{
				charFrequencies.put(ch, charFrequencies.get(ch) + 1);
			}
			else
			{
				charFrequencies.put(ch, 1);
			}
			*/
			charFrequencies.computeIfPresent(ch, (key, value) -> value + 1);
			charFrequencies.putIfAbsent(ch, 1);
		}
		return charFrequencies;
	}
	
	
	static boolean allAnagrams(List<String> words) {
		if (words.size() < 2)
			return false;
		
		for (int i = 0; i < words.size() -1; i++)
		{
			String word1 = words.get(i);
			String word2 = words.get(i + 1);

			boolean isAnagram = isAnagram(word1, word2);
			if (!isAnagram)
				return false;
		}
		
		return true;
	}
}
